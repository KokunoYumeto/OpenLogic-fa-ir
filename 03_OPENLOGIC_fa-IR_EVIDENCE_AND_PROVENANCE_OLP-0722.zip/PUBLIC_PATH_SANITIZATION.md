# Public-path sanitization receipt

All evidence inputs were selected from explicit publication-control, receipt,
and final-build paths. Absolute paths rooted at the local Windows user profile
were replaced case-insensitively by `<LOCAL_USER_ROOT>`. The obsolete
pre-OLP-0722 DOI, where retained in a historical control record, was replaced
by `<OBSOLETE_VERSION_DOI>`. Line endings were normalized to LF. No credential
file, credential value, temporary render, stale build tree, PDF, AUX, OUT, TOC,
THM, PCR, or PRB file is included in this evidence archive.
